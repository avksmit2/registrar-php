-- phpMyAdmin SQL Dump
-- version 4.5.5.1
-- http://www.phpmyadmin.net
--
-- Host: localhost:8080
-- Generation Time: Sep 27, 2016 at 11:22 PM
-- Server version: 5.7.11
-- PHP Version: 5.6.19

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `registrar_test`
--
CREATE DATABASE IF NOT EXISTS `registrar_test` DEFAULT CHARACTER SET utf8 COLLATE utf8_general_ci;
USE `registrar_test`;

-- --------------------------------------------------------

--
-- Table structure for table `courses`
--

CREATE TABLE `courses` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `course_name` varchar(255) DEFAULT NULL,
  `course_number` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `courses_students`
--

CREATE TABLE `courses_students` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `course_id` int(11) DEFAULT NULL,
  `student_id` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `courses_students`
--

INSERT INTO `courses_students` (`id`, `course_id`, `student_id`) VALUES
(1, 13, 4),
(2, 14, 5),
(3, 14, 6),
(4, 20, 7),
(5, 21, 8),
(6, 21, 9),
(7, 27, 10),
(8, 28, 11),
(9, 28, 12),
(10, 34, 13),
(11, 35, 14),
(12, 35, 15),
(13, 41, 23),
(14, 42, 24),
(15, 42, 25),
(16, 48, 33),
(17, 49, 34),
(18, 49, 35),
(19, 57, 43),
(20, 58, 44),
(21, 58, 45),
(22, 66, 53),
(23, 67, 54),
(24, 67, 55),
(25, 75, 63),
(26, 76, 64),
(27, 76, 65),
(28, 84, 74),
(29, 85, 75),
(30, 85, 76),
(31, 93, 86),
(32, 94, 87),
(33, 94, 88),
(34, 102, 97),
(35, 103, 98),
(36, 103, 99),
(37, 119, 109),
(38, 120, 110),
(39, 120, 111),
(40, 130, 121),
(41, 131, 122),
(42, 131, 123),
(43, 144, 135),
(44, 145, 136),
(45, 145, 137),
(46, 158, 149),
(47, 159, 150),
(48, 159, 151),
(49, 160, 161),
(50, 161, 162),
(51, 162, 162),
(52, 172, 163),
(53, 173, 164),
(54, 173, 165),
(55, 174, 175),
(56, 175, 176),
(57, 176, 176),
(58, 186, 177),
(59, 187, 178),
(60, 187, 179),
(61, 188, 189),
(62, 189, 190),
(63, 190, 190),
(64, 200, 191),
(65, 201, 192),
(66, 201, 193),
(67, 204, 203),
(68, 205, 204),
(69, 206, 204),
(70, 216, 205),
(71, 217, 206),
(72, 217, 207),
(73, 220, 217),
(74, 221, 218),
(75, 222, 218),
(76, 232, 221),
(77, 233, 222),
(78, 233, 223),
(79, 236, 233),
(80, 237, 234),
(81, 238, 234);

-- --------------------------------------------------------

--
-- Table structure for table `students`
--

CREATE TABLE `students` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `student_name` varchar(255) DEFAULT NULL,
  `enroll_date` date DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Indexes for dumped tables
--

--
-- Indexes for table `courses`
--
ALTER TABLE `courses`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `id` (`id`);

--
-- Indexes for table `courses_students`
--
ALTER TABLE `courses_students`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `id` (`id`);

--
-- Indexes for table `students`
--
ALTER TABLE `students`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `id` (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `courses`
--
ALTER TABLE `courses`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=239;
--
-- AUTO_INCREMENT for table `courses_students`
--
ALTER TABLE `courses_students`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=82;
--
-- AUTO_INCREMENT for table `students`
--
ALTER TABLE `students`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=237;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
